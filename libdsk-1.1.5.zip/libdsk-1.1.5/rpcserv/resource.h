//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by DDEMLSV.RC
//
#define IDS_BADLENGTH                   1
#define IDM_ABOUT                       100
#define IDEF_VALUE                      101
#define IDTX_VALUE                      102
#define IDEF_DATA                       103
#define IDBN_GENHUGE                    104
#define IDEF_FLAGS                      110
#define IDEF_COUNTRY                    111
#define IDEF_CODEPAGE                   112
#define IDEF_LANG                       113
#define IDEF_SECURITY                   114
#define IDM_BLOCKALLCBS                 200
#define IDM_ENABLEONECB                 201
#define IDM_BLOCKNEXTCB                 202
#define IDM_TERMNEXTCB                  203
#define IDM_RUNAWAY                     204
#define IDM_CHANGEDATA                  205
#define IDM_EXIT                        205
#define IDM_RENDERDELAY                 206
#define IDM_SETTOPIC                    207
#define IDM_SETSERVER                   208
#define IDM_UNBLOCKALLCBS               209
#define IDM_HELP                        210
#define IDM_CONTEXT                     211
#define IDM_APPOWNED                    212
#define IDC_TITLE                       213
#define IDC_BOTTOMFRAME                 214
#define IDC_TOPFRAME                    1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         101
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
