/* Dummy file to satisfy MSVC++ 1.x dependency scanner */
